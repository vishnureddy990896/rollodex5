export const monsterActionTypes={
    // keyvalue pair,reuseable object key constants
    SEARCH_MONSTER:"SEARCH-MONSTERS"
}